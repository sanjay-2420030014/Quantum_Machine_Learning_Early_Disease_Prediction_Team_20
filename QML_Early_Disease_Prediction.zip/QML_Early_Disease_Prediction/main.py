# ============================================================
# Quantum Machine Learning for Heart Disease Prediction
# ============================================================
#
# Dataset:
# UCI Heart Disease - Cleveland Dataset
#
# Pipeline:
# Dataset
#    ↓
# Data Cleaning
#    ↓
# Train/Test Split
#    ↓
# Standardization
#    ↓
# PCA (13 features -> 4 components)
#    ↓
# Classical SVC
#    ↓
# Fidelity Quantum Kernel
#    ↓
# QSVC
#    ↓
# Evaluation
#    ↓
# Confusion Matrix + Performance Comparison
#
# ============================================================

import os
import urllib.request

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report
)

from qiskit.circuit.library import ZZFeatureMap
from qiskit_machine_learning.kernels import FidelityQuantumKernel
from qiskit_machine_learning.algorithms import QSVC


# ============================================================
# 1. CREATE DATA DIRECTORY
# ============================================================

os.makedirs("data", exist_ok=True)


# ============================================================
# 2. LOAD UCI HEART DISEASE DATASET
# ============================================================

print("=" * 60)
print("QUANTUM MACHINE LEARNING FOR HEART DISEASE PREDICTION")
print("=" * 60)

print("\nLoading UCI Heart Disease dataset...")

url = (
    "https://archive.ics.uci.edu/ml/machine-learning-databases/"
    "heart-disease/processed.cleveland.data"
)

data_file = os.path.join("data", "heart_disease_cleveland.csv")


# Download dataset if it does not already exist
if not os.path.exists(data_file):

    try:
        urllib.request.urlretrieve(url, data_file)
        print("Dataset downloaded successfully.")

    except Exception as e:
        print("\nDataset download failed.")
        print("Error:", e)
        print("\nPlease check your internet connection.")
        raise

else:
    print("Dataset already exists locally.")


# ============================================================
# 3. DATASET COLUMN NAMES
# ============================================================

columns = [
    "age",
    "sex",
    "cp",
    "trestbps",
    "chol",
    "fbs",
    "restecg",
    "thalach",
    "exang",
    "oldpeak",
    "slope",
    "ca",
    "thal",
    "target"
]


# ============================================================
# 4. READ DATASET
# ============================================================

df = pd.read_csv(
    data_file,
    names=columns,
    na_values="?"
)

print("\nDataset loaded.")

print("Dataset shape before cleaning:", df.shape)


# ============================================================
# 5. DATA CLEANING
# ============================================================

print("\nCleaning dataset...")

# Convert columns to numeric
for column in columns:
    df[column] = pd.to_numeric(df[column], errors="coerce")


# Display missing values
print("\nMissing values before cleaning:")

print(df.isnull().sum())


# Replace missing numerical values using median
for column in columns:

    if df[column].isnull().sum() > 0:

        median_value = df[column].median()

        df[column] = df[column].fillna(median_value)


# Convert target into binary classification
#
# Original UCI target:
# 0 = no heart disease
# 1,2,3,4 = presence of heart disease
#
# New target:
# 0 = No Heart Disease
# 1 = Heart Disease Present

df["target"] = df["target"].apply(
    lambda x: 0 if x == 0 else 1
)


print("\nMissing values after cleaning:")

print(df.isnull().sum().sum())

print("\nDataset shape after cleaning:", df.shape)

print("\nTarget classes:")
print(df["target"].value_counts())


# ============================================================
# 6. SAVE CLEANED DATASET
# ============================================================

cleaned_file = os.path.join(
    "data",
    "cleaned_heart_disease.csv"
)

df.to_csv(cleaned_file, index=False)

print("\nCleaned dataset saved to:")
print(cleaned_file)


# ============================================================
# 7. SEPARATE FEATURES AND TARGET
# ============================================================

X = df.drop("target", axis=1)

y = df["target"]


print("\nFeature shape:", X.shape)
print("Target shape:", y.shape)

print("\nClasses:")
print(
    ["No Heart Disease", "Heart Disease"]
)


# ============================================================
# 8. TRAIN / TEST SPLIT
# ============================================================

print("\nPerforming 80:20 stratified train-test split...")

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)


print("\nTraining samples:", len(X_train))
print("Testing samples:", len(X_test))


# ============================================================
# 9. STANDARDIZATION
# ============================================================

print("\nStandardizing features...")

scaler = StandardScaler()

X_train_scaled = scaler.fit_transform(X_train)

X_test_scaled = scaler.transform(X_test)


print("Standardization completed.")


# ============================================================
# 10. PCA DIMENSIONALITY REDUCTION
# ============================================================

print("\nApplying PCA...")

pca = PCA(
    n_components=4,
    random_state=42
)

X_train_pca = pca.fit_transform(X_train_scaled)

X_test_pca = pca.transform(X_test_scaled)


print(
    "Original number of features:",
    X_train.shape[1]
)

print(
    "Features after PCA:",
    X_train_pca.shape[1]
)

print(
    "Training shape after PCA:",
    X_train_pca.shape
)

# ============================================================
# PREPARE MATCHED TRAINING SUBSET FOR FAIR SVC vs QSVC COMPARISON
# ============================================================

print("\nPreparing matched training subset for fair comparison...")

from sklearn.model_selection import train_test_split

# Both SVC and QSVC will use exactly the same 120 samples.
# Stratification keeps the class distribution balanced.

X_train_matched, _, y_train_matched, _ = train_test_split(
    X_train_pca,
    y_train,
    train_size=120,
    random_state=42,
    stratify=y_train
)

print(
    "Full training samples:",
    len(X_train_pca)
)

print(
    "Matched training samples:",
    len(X_train_matched)
)

print(
    "Matched SVC training samples:",
    len(X_train_matched)
)

print(
    "Matched QSVC training samples:",
    len(X_train_matched)
)

print(
    "Test samples:",
    len(X_test_pca)
)

print(
    "Testing shape after PCA:",
    X_test_pca.shape
)

print(
    "Explained variance ratio:",
    pca.explained_variance_ratio_
)

print(
    "Total explained variance:",
    pca.explained_variance_ratio_.sum()
)


# ============================================================
# 11. CLASSICAL SVC
# ============================================================

print("\n" + "=" * 60)
print("TRAINING CLASSICAL SVC")
print("=" * 60)

svc = SVC(
    kernel="rbf",
    random_state=42
)

svc.fit(
    X_train_matched,
    y_train_matched
)


# Predict test data
y_pred_svc = svc.predict(X_test_pca)


# Calculate metrics
svc_accuracy = accuracy_score(
    y_test,
    y_pred_svc
)

svc_precision = precision_score(
    y_test,
    y_pred_svc,
    zero_division=0
)

svc_recall = recall_score(
    y_test,
    y_pred_svc,
    zero_division=0
)

svc_f1 = f1_score(
    y_test,
    y_pred_svc,
    zero_division=0
)


print("\nClassical SVC Results")

print(
    f"Accuracy: {svc_accuracy * 100:.2f}%"
)

print(
    f"Precision: {svc_precision * 100:.2f}%"
)

print(
    f"Recall: {svc_recall * 100:.2f}%"
)

print(
    f"F1 Score: {svc_f1 * 100:.2f}%"
)


# ============================================================
# 12. CREATE QUANTUM FEATURE MAP
# ============================================================

print("\n" + "=" * 60)
print("CREATING QUANTUM FEATURE MAP")
print("=" * 60)

num_qubits = 4

feature_map = ZZFeatureMap(
    feature_dimension=num_qubits,
    reps=2,
    entanglement="linear"
)


print("\nQuantum feature map created.")

print("Number of qubits:", num_qubits)

print("Feature map:")
print(feature_map)


# ============================================================
# 13. CREATE FIDELITY QUANTUM KERNEL
# ============================================================

print("\n" + "=" * 60)
print("CREATING FIDELITY QUANTUM KERNEL")
print("=" * 60)

quantum_kernel = FidelityQuantumKernel(
    feature_map=feature_map
)


print("\nFidelity Quantum Kernel created successfully.")


# ============================================================
# 14. USE SAME MATCHED TRAINING DATA FOR QSVC
# ============================================================

print("\nPreparing QSVC training data...")

# Use exactly the same 120 samples used by Classical SVC.
# This ensures a fair SVC vs QSVC comparison.

X_train_qsvc = X_train_matched

y_train_qsvc = y_train_matched

print(
    "Original training samples:",
    len(X_train_pca)
)

print(
    "Matched SVC training samples:",
    len(X_train_matched)
)

print(
    "Matched QSVC training samples:",
    len(X_train_qsvc)
)

print(
    "QSVC test samples:",
    len(X_test_pca)
)



# ============================================================
# 15. CREATE QSVC
# ============================================================

print("\nCreating QSVC...")

qsvc = QSVC(
    quantum_kernel=quantum_kernel
)


print("QSVC created successfully.")


# ============================================================
# 16. TRAIN QSVC
# ============================================================

print("\n" + "=" * 60)
print("TRAINING QSVC")
print("=" * 60)

print(
    "\nQuantum kernel simulation can take time."
)

print(
    "Please wait for QSVC training to complete..."
)


qsvc.fit(
    X_train_qsvc,
    y_train_qsvc
)


print("\nQSVC training completed.")


# ============================================================
# 17. QSVC PREDICTION
# ============================================================

print("\n" + "=" * 60)
print("QSVC PREDICTION")
print("=" * 60)

print("\nPredicting test samples...")


y_pred_qsvc = qsvc.predict(
    X_test_pca
)


print(
    "QSVC prediction completed."
)


# ============================================================
# 18. QSVC EVALUATION
# ============================================================

qsvc_accuracy = accuracy_score(
    y_test,
    y_pred_qsvc
)

qsvc_precision = precision_score(
    y_test,
    y_pred_qsvc,
    zero_division=0
)

qsvc_recall = recall_score(
    y_test,
    y_pred_qsvc,
    zero_division=0
)

qsvc_f1 = f1_score(
    y_test,
    y_pred_qsvc,
    zero_division=0
)


print("\nQSVC Results")

print(
    f"Accuracy: {qsvc_accuracy * 100:.2f}%"
)

print(
    f"Precision: {qsvc_precision * 100:.2f}%"
)

print(
    f"Recall: {qsvc_recall * 100:.2f}%"
)

print(
    f"F1 Score: {qsvc_f1 * 100:.2f}%"
)


# ============================================================
# 19. CONFUSION MATRIX
# ============================================================

print("\n" + "=" * 60)
print("QSVC CONFUSION MATRIX")
print("=" * 60)

cm = confusion_matrix(
    y_test,
    y_pred_qsvc
)


print("\nConfusion Matrix:")

print(cm)


# ============================================================
# 20. CLASSIFICATION REPORT
# ============================================================

print("\nQSVC Classification Report:")

print(
    classification_report(
        y_test,
        y_pred_qsvc,
        target_names=[
            "No Heart Disease",
            "Heart Disease"
        ],
        zero_division=0
    )
)


# ============================================================
# 21. SAVE CONFUSION MATRIX IMAGE
# ============================================================

plt.figure(
    figsize=(7, 5)
)

plt.imshow(
    cm,
    interpolation="nearest"
)

plt.title(
    "QSVC Confusion Matrix - Heart Disease"
)

plt.colorbar()

plt.xticks(
    [0, 1],
    [
        "No Heart Disease",
        "Heart Disease"
    ]
)

plt.yticks(
    [0, 1],
    [
        "No Heart Disease",
        "Heart Disease"
    ]
)

plt.xlabel(
    "Predicted Class"
)

plt.ylabel(
    "Actual Class"
)


for i in range(2):

    for j in range(2):

        plt.text(
            j,
            i,
            cm[i, j],
            ha="center",
            va="center"
        )


plt.tight_layout()

confusion_matrix_file = (
    "QSVC_Heart_Disease_Confusion_Matrix.png"
)

plt.savefig(
    confusion_matrix_file,
    dpi=300,
    bbox_inches="tight"
)

plt.close()


print(
    "\nConfusion matrix saved as:"
)

print(
    confusion_matrix_file
)


# ============================================================
# 22. PERFORMANCE COMPARISON
# ============================================================

metrics = [
    "Accuracy",
    "Precision",
    "Recall",
    "F1 Score"
]

svc_values = [
    svc_accuracy * 100,
    svc_precision * 100,
    svc_recall * 100,
    svc_f1 * 100
]

qsvc_values = [
    qsvc_accuracy * 100,
    qsvc_precision * 100,
    qsvc_recall * 100,
    qsvc_f1 * 100
]


x = np.arange(
    len(metrics)
)

width = 0.35


plt.figure(
    figsize=(9, 6)
)

plt.bar(
    x - width / 2,
    svc_values,
    width,
    label="Classical SVC"
)

plt.bar(
    x + width / 2,
    qsvc_values,
    width,
    label="QSVC"
)


plt.xticks(
    x,
    metrics
)

plt.ylabel(
    "Score (%)"
)

plt.xlabel(
    "Evaluation Metrics"
)

plt.title(
    "Classical SVC vs QSVC - Heart Disease Prediction"
)

plt.ylim(
    0,
    100
)

plt.legend()

plt.grid(
    axis="y",
    alpha=0.3
)


plt.tight_layout()


comparison_file = (
    "SVC_vs_QSVC_Heart_Disease_Comparison.png"
)

plt.savefig(
    comparison_file,
    dpi=300,
    bbox_inches="tight"
)

plt.close()


print(
    "\nPerformance comparison saved as:"
)

print(
    comparison_file
)


# ============================================================
# 23. SAVE RESULTS TO CSV
# ============================================================

results = pd.DataFrame(
    {
        "Metric": metrics,
        "Classical SVC": svc_values,
        "QSVC": qsvc_values
    }
)


results_file = (
    "Heart_Disease_QML_Results.csv"
)

results.to_csv(
    results_file,
    index=False
)


print(
    "\nResults saved as:"
)

print(
    results_file
)


# ============================================================
# 24. FINAL SUMMARY
# ============================================================

print("\n" + "=" * 60)
print("FINAL PROJECT SUMMARY")
print("=" * 60)

print(
    "\nDataset: UCI Heart Disease - Cleveland"
)

print(
    "Total samples:",
    len(df)
)

print(
    "Original features:",
    X.shape[1]
)

print(
    "PCA components:",
    X_train_pca.shape[1]
)

print(
    "Training samples:",
    len(X_train)
)

print(
    "Testing samples:",
    len(X_test)
)

print(
    "QSVC training samples:",
    len(X_train_qsvc)
)

print(
    f"\nClassical SVC Accuracy: "
    f"{svc_accuracy * 100:.2f}%"
)

print(
    f"QSVC Accuracy: "
    f"{qsvc_accuracy * 100:.2f}%"
)

print("\nImplementation completed successfully.")

print("=" * 60)