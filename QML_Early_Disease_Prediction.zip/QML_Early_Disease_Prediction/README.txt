============================================================
QUANTUM MACHINE LEARNING FOR HEART DISEASE PREDICTION
============================================================

PROJECT DESCRIPTION
-------------------

This project implements a proof-of-concept Quantum Machine
Learning pipeline for binary heart disease classification.

The project compares:

1. Classical Support Vector Classifier (SVC)
2. Quantum Support Vector Classifier (QSVC)

The UCI Heart Disease Cleveland dataset is used.

------------------------------------------------------------

DATASET
-------

Dataset:
UCI Heart Disease - Cleveland Dataset

Number of samples:
303

Original input features:
13

Target:
Heart Disease

Target classes:

0 = No Heart Disease
1 = Heart Disease Present

------------------------------------------------------------

PROJECT PIPELINE
----------------

Dataset
   |
   v
Data Cleaning
   |
   v
Train/Test Split
   |
   v
Standardization
   |
   v
PCA
13 Features -> 4 Components
   |
   +----------------------+
   |                      |
   v                      v
Classical SVC        Quantum Feature Map
                          |
                          v
                   Fidelity Quantum Kernel
                          |
                          v
                         QSVC
                          |
                          v
                       Prediction
                          |
                          v
                       Evaluation

------------------------------------------------------------

TECHNOLOGIES USED
-----------------

Python
Pandas
NumPy
Scikit-learn
Qiskit
Qiskit Machine Learning
Matplotlib

------------------------------------------------------------

IMPLEMENTATION STEPS
--------------------

1. Load the UCI Heart Disease dataset.

2. Convert missing values represented by '?' into NaN.

3. Replace missing numerical values using the median.

4. Convert the original target into binary classification.

5. Split the dataset into training and testing sets.

6. Standardize the input features using StandardScaler.

7. Apply PCA to reduce 13 features to 4 components.

8. Train a classical SVC model.

9. Create a 4-qubit ZZFeatureMap.

10. Create a FidelityQuantumKernel.

11. Train QSVC using a fixed reduced training subset.

12. Predict the test samples.

13. Calculate:
    - Accuracy
    - Precision
    - Recall
    - F1 Score

14. Generate the QSVC confusion matrix.

15. Generate the SVC vs QSVC comparison graph.

------------------------------------------------------------

WHY PCA IS USED
---------------

The original dataset contains 13 input features.

Quantum feature maps are computationally expensive to simulate.

Therefore, PCA is used to reduce the feature space:

13 Features -> 4 Principal Components

The four components are then mapped to a four-qubit
quantum feature representation.

------------------------------------------------------------

WHY A REDUCED QSVC TRAINING SET IS USED
---------------------------------------

Quantum kernel simulation requires calculating quantum
circuit-based kernel values.

This becomes computationally expensive as the number
of training samples increases.

Therefore, a fixed random subset of up to 120 training
samples is used for the QSVC experiment.

The complete test set is retained for evaluation.

The random seed is fixed at 42 to make the experiment
repeatable.

------------------------------------------------------------

HOW TO RUN
----------

Step 1:
Open Command Prompt or Terminal.

Step 2:
Go to the project folder.

Example:

cd D:\CLG\QC\hackathon\QML_Heart_Disease_Prediction

Step 3:
Install dependencies:

pip install -r requirements.txt

Step 4:
Run:

python main.py

------------------------------------------------------------

OUTPUT FILES
------------

After execution, the following files are generated:

data/heart_disease_cleveland.csv

data/cleaned_heart_disease.csv

QSVC_Heart_Disease_Confusion_Matrix.png

SVC_vs_QSVC_Heart_Disease_Comparison.png

Heart_Disease_QML_Results.csv

------------------------------------------------------------

IMPORTANT NOTE
--------------

This project is a research and educational proof-of-concept.

The results should not be interpreted as a clinically
validated medical diagnostic system.

The comparison between Classical SVC and QSVC should be
interpreted according to the experimental setup because
the classical model uses the complete training set while
the QSVC uses a reduced training subset due to quantum
kernel simulation cost.

============================================================
END
============================================================